


## Базова конфигурация

```powershell
Get-Date
```
